var express = require('express');
var router = express.Router();
var pool = require('./pool')
const { response } = require('../app')
var upload = require('./multer')


/* GET users listing. */
router.post('/add_new_productlist', upload.single('images'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("insert into productlist (categoryid,productid,weight,price,offerprice, description,images,createdat,updatedat,createdby,companyid)values(?,?,?,?,?,?,?,?,?,?,?)", [req.body.categoryid, req.body.productid, req.body.weight, req.body.price, req.body.offerprice, req.body.description, req.file.originalname, req.body.createdat, req.body.updatedat, req.body.createdby, req.body.companyid], function (error, result) {
    if (error) {
      console.log("xxxx", error)
      res.status(500).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Products Added Successfully' })
    }

  })
});




router.get('/fetch_all_productlist', function (req, res, next) {
  pool.query("select * from productlist", function (error, result) {
    if (error) {
      console.log(error)
      res.status(300).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, data: result })
      console.info("xxxxxx", result)

    }

  })
});

router.post('/edit_productlist_data', function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("update productlist set categoryid=?,productid=?,weight=?,price=?,offerprice=?, description=?,updatedat=?,createdby=?,companyid=? where productlistid=?", [req.body.categoryid, req.body.productid, req.body.weight, req.body.price, req.body.offerprice, req.body.description, req.body.updatedat, req.body.createdby, req.body.companyid, req.body.productlistid], function (error, result) {
    if (error) {
      console.log(error)
      res.status(200).json({ status: false, message: 'Server error....' })
    }
    else {
      // console.log("dscs", result)
      res.status(200).json({ status: true, message: 'Products Updated Successfully' })
    }

  })
});




router.post('/edit_productlist_logo', upload.single('images'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("update productlist set images=? where productlistid=? ", [req.file.originalname,req.body.productlistid], function (error, result) {
    if (error) {
      console.log(error)
      res.status(200).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Image Updated' })
    }

  })
});

router.post('/delete_productlist_data', upload.single('logo'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("delete from productlist  where productlistid=? ", [req.body.productlistid], function (error, result) {
    if (error) {
      console.log(error)
      res.status(200).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Product Deleted Successfully' })
    }

  })
});

module.exports = router;