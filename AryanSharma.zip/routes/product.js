var express = require('express');
var router = express.Router();
var pool = require('./pool')
const { response } = require('../app')
var upload = require('./multer')


/* GET users listing. */
router.post('/add_new_product', upload.single('image'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("insert into products ( companyid,categoryid,productname, description,status,trending,deals,pricetype,image,createdat,updatedat,createdby,statuss)values(?,?,?,?,?,?,?,?,?,?,?,?,?)", [req.body.companyid, req.body.categoryid, req.body.productname, req.body.description, req.body.status, req.body.trending, req.body.deals, req.body.pricetype, req.file.originalname, req.body.createdat, req.body.updatedat, req.body.createdby, req.body.statuss], function (error, result) {
    if (error) {
      console.log("xxxx", error)
      res.status(500).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Products Added Successfully' })
    }

  })
});




router.get('/fetch_all_products', function (req, res, next) {
  pool.query("select * from products", function (error, result) {
    if (error) {
      console.log(error)
      res.status(300).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, data: result })
      console.info("xxxxxx", result)

    }

  })
});

router.post('/edit_product_data', upload.single('image'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("update products set companyid=?,categoryid=?,productname=?, description=?,status=?,trending=?,deals=?,pricetype=?,updatedat=?,createdby=?,statuss=? where productid=?", [req.body.companyid, req.body.categoryid, req.body.productname, req.body.description, req.body.status, req.body.trending, req.body.deals, req.body.pricetype, req.body.updatedat, req.body.createdby, req.body.statuss, req.body.productid], function (error, result) {
    if (error) {
      console.log(error)
      res.status(200).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Products Added Successfully' })
    }

  })
});




router.post('/edit_product_logo', upload.single('image'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("update products set image=? where productid=? ", [req.file.originalname, req.body.productid], function (error, result) {
    if (error) {
      console.log(error)
      res.status(200).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Image Updated' })
    }

  })
});

router.get('/fetch_productid', function (req, res, next) {
  // console.log(req.body)
  // console.log(req.file)
  pool.query("select * from products", function (error, result) {

    if (error) {
      console.log("xxxx", error)
      res.status(500).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, data: result })
    }


  })
})

router.post('/delete_product_data', upload.single('logo'), function (req, res, next) {
  console.log(req.body)
  console.log(req.file)
  pool.query("delete from products  where productid=? ", [req.body.productid], function (error, result) {
    if (error) {
      console.log(error)
      res.status(200).json({ status: false, message: 'Server error....' })
    }
    else {
      res.status(200).json({ status: true, message: 'Product Deleted Successfully' })
    }

  })
});

module.exports = router;


