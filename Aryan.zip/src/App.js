import Company from "./components/administrator/Company"; 
import DisplayAllCompanies from "./components/administrator/DisplayAllCompanies";
import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import Category from "./components/administrator/Category";
import DisplayAllCategories from "./components/administrator/DisplayAllCategories";
import Product from "./components/administrator/Product";
import DisplayAllProducts from "./components/administrator/DisplayAllProducts";
import AdminLogin from "./components/administrator/AdminLogin";
import ProductList from "./components/administrator/ProductList";
import DisplayAllProductList from "./components/administrator/DisplayAllProductList";
function App() {
  return (
    <div>
      <Router>
        <Routes>
        <Route element={<Company/>} path="/" />
           <Route element={<Company/>} path="/company" />
           <Route element={<DisplayAllCompanies/>} path={"/displayallcompanies"} />
           <Route element={<Category/>} path="/category" />
           <Route element={<DisplayAllCategories/>} path="/displayallcategories" />
           <Route element={<Product/>} path="/product" />
           <Route element={<DisplayAllProducts/>} path="/displayallproducts" />
           <Route element={<AdminLogin/>} path="/adminlogin" />
           <Route element={<ProductList/>} path="/productlist" />
           <Route element={<DisplayAllProductList/>} path="/displayallproductlist" />
        </Routes>
      </Router>
    </div>
  );
}

export default App
