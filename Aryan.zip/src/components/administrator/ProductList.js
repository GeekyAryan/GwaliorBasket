import React, { useEffect, useState } from "react";
import { Avatar, TextField, Button, Grid, IconButton, FormControl, OutlinedInput, InputAdornment, Select, MenuItem, InputLabel, FormLabel, FormControlLabel, } from "@mui/material";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import Radio from '@mui/material/Radio';
// import Visibility from "@mui/icons-material/Visibility";
// import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useStyles } from "./ProductListCss";
import { getData, postData } from "../services/ServerServices";
import { useNavigate } from 'react-router-dom';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import Swal from "sweetalert2";

export default function Product(props) {
  var classes = useStyles();
  var navigate = useNavigate();

  const [productlistid, setProductListId] = useState('')
  const [categoryid, setCategoryId] = useState('')
  const [productid, setProductId] = useState('')
  const [weight, setWeight] = useState('')
  const [price, setPrice] = useState('')
  const [offerprice, setOfferPrice] = useState('')
  const [description, setDescription] = useState('')
  const [images, setImages] = useState({ fileName: '/assets/watermark.png', bytes: '' });
  const [companyid, setCompanyId] = useState('')

  const [fillCategoryid, setFillCategoryid] = useState([])
  const [fillProductid, setFillProductid] = useState([])
  const [fillCompanyid, setFillCompanyid] = useState([])
  // var result = await postData('product/add_new_product', formData)

  const [error, setError] = useState({})


  const handleClick = async () => {
  
    if (validation()) {
      var cd = new Date()
      var dd = cd.getFullYear() + "/" + (cd.getMonth() + 1) + "/" + cd.getDate() + " " + cd.getHours() + ":" + cd.getMinutes()
      var formData = new FormData()
      // formData.append('productlistid', productlistid)
      formData.append('categoryid', categoryid)
      formData.append('productid', productid)
      formData.append('weight', weight)
      formData.append('price', price)
      formData.append('offerprice', offerprice)
      formData.append('description', description)
      formData.append('images', images.bytes)
      formData.append('createdat', dd)
      formData.append('updatedat', dd)
      formData.append('createdby', 'ADMIN')
      formData.append('companyid', companyid)
      var result = await postData('productlist/add_new_productlist', formData)
      // alert(result.status)
      if (result.status) {
        Swal.fire({
          icon: 'success',
          title: result.message,
        })
      }
      else {
        Swal.fire({
          icon: 'error',
          title: result.message,
        })
      }
    }
  }
  const clearValue = () => {
    setCompanyId('')
    setCategoryId('Choose Category...')
    setProductId('choose Product...')
    setWeight('')
    setPrice('')
    setOfferPrice('')
    setDescription('')
    setImages({ fileName: '/assets/watermark.png', bytes: '' })
    setCompanyId('')
  }







  const handleImage = (event) => {
    setImages({ fileName: URL.createObjectURL(event.target.files[0]), bytes: event.target.files[0] });
  };
  console.log()

  const fatchAllCategories = async () => {
    var result = await getData('category/fetch_categoryid')
    setFillCategoryid(result.data)
  }

  const fatchAllProducts = async () => {
    var result = await getData('product/fetch_productid')
    setFillProductid(result.data)
  }

  const fatchAllCompany = async () => {
    var result = await getData('company/fetch_companyid')
    setFillCompanyid(result.data)
  }

  useEffect(function () {
    fatchAllCategories()
  }, [])

  useEffect(function () {
    fatchAllProducts()
  }, [])

  useEffect(function () {
    fatchAllCompany()
  }, [])

  const handleError = (inputs, value) => {
    setError((prev) => ({ ...prev, [inputs]: value }))
  }

  const validation = () => {

    var isValid = true
    // if (!productlistid) {
    //   handleError("productlistid", "Invalid ProductListId Name")
    //   isValid = false
    // }

    if (!categoryid) {
      handleError("categoryid", "Invalid categoryId Name")
      isValid = false
    }

    if (!productid) {
      handleError("productid", "Invalid Productid")
      isValid = false
    }
    if (!weight) {
      handleError('weight', "Invalid Weight")
    }


    if (!price) {
      handleError('price', "Pls Enter Price")
      isValid = false
    }

    if (!offerprice) {
      handleError('offerprice', "Pls Enter OfferPrice")
      isValid = false
    }


    if (!description) {
      handleError('description', "Pls Input Description")
      isValid = false
    }



    if (!companyid) {
      handleError("companyid", "Invalid CompanyId Name")
      isValid = false
    }

    return isValid
  }



  const fill_Categoryid = () => {
    return fillCategoryid.map((item) => {
      return (<MenuItem value={item.categoryid}> {item.category}</MenuItem>)
    })
  }

  const fill_Productid = () => {
    return fillProductid.map((item) => {
      return (<MenuItem value={item.productid}> {item.productname}</MenuItem>)
    })
  }

  const fill_Companyid = () => {
    return fillCompanyid.map((item) => {
      return (<MenuItem value={item.companyid}> {item.companyname}</MenuItem>)
    })
  }

  const handleCategoryChange = (event) => {
    setCategoryId(event.target.value)
  }

  const handleProductChange = (event) => {
    setProductId(event.target.value)
  }

  const handleCompanyChange = (event) => {
    setCompanyId(event.target.value)
  }

  return (<>
    <div className={classes.mainContainer}>
      <div className={classes.box}>
        <Grid container spacing={2}>
          <Grid item xs={12}  >

            <div style={{ display: 'flex', flexDirection: 'row' }}>
              <div className={classes.headingStyle}>
                ProductList Details
              </div>

            </div>

            <div>
              <FormatListBulletedIcon onClick={() => navigate('/displayallproductlist')} />
            </div>
          </Grid>


          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Category Id</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={categoryid}
                label="categoryid"
                onChange={handleCategoryChange}
                error={!error.categoryid ? false : true}
                onFocus={() => handleError('categorid', null)}
              >
                <MenuItem value={'Choose Category...'}>Choose Category...</MenuItem>
                {fill_Categoryid()}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Product Id</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={productid}
                label="productid"
                onChange={handleProductChange}
                error={!error.productid ? false : true}
                onFocus={() => handleError('productid', null)}
              >
                <MenuItem value={'Choose Product...'}>Choose Product Id...</MenuItem>
                {fill_Productid()}
              </Select>
            </FormControl>
          </Grid>



          <Grid item xs={6} >
            <TextField error={!error.weight ? false : true} helperText={error.weight} onFocus={() => handleError("weight", null)} value={weight} onChange={(event) => setWeight(event.target.value)} fullWidth label="Weight" variant="outlined" />
          </Grid>


          <Grid item xs={6} >
            <TextField error={!error.price ? false : true} helperText={error.price} onFocus={() => handleError("price", null)} value={price} onChange={(event) => setPrice(event.target.value)} fullWidth label="Price" variant="outlined" />
          </Grid>

          <Grid item xs={6} >
            <TextField error={!error.offerprice ? false : true} helperText={error.offerprice} onFocus={() => handleError("offerprice", null)} value={offerprice} onChange={(event) => setOfferPrice(event.target.value)} fullWidth label="Offer Price" variant="outlined" />
          </Grid>

          <Grid item xs={12}>
            <TextField error={!error.description ? false : true} helperText={error.description} onFocus={() => handleError("description", null)} value={description} fullWidth onChange={(event) => setDescription(event.target.value)} label="Description" variant="outlined" />
          </Grid>





          <Grid item xs={3}>
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 12 }}>

              <IconButton color="primary" aria-label="upload picture" component="label">
                <input hidden accept="image/*" type="file" onChange={handleImage} />
                <PhotoCamera />
              </IconButton>
            </div>
          </Grid>

          <Grid item xs={3}>
            <Avatar
              alt="Remy Sharp"
              variant="rounded"
              src={images.fileName}
              sx={{ width: 56, height: 56 }}
            />
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Company Id</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={companyid}
                label="companyid"
                onChange={handleCompanyChange}
                error={!error.productid ? false : true}
                onFocus={() => handleError('companyid', null)}
              >
                <MenuItem value={'Choose Company Id...'}>Choose Company Id...</MenuItem>
                {fill_Companyid()}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={3}>
            <Button fullWidth variant="contained" onClick={handleClick}>Submit</Button>
          </Grid>
          <Grid item xs={3}>
            <Button fullWidth variant="contained" onClick={handleClick}>Reset</Button>
          </Grid>
        </Grid>
      </div>
    </div>
  </>

  )
}