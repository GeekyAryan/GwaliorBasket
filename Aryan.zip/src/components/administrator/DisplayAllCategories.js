import { useEffect, useState } from 'react'
import MaterialTable from "@material-table/core";
import { getData, postData, ServerURL } from '../services/ServerServices';
import { useNavigate } from 'react-router-dom';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Switch, Avatar, TextField, Grid, IconButton, FormControl, InputLabel, OutlinedInput, InputAdornment, Select, MenuItem, } from '@mui/material';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import Swal from 'sweetalert2';

import CloseIcon from '@mui/icons-material/Close';
import { useStyles } from "./DisplayAllCategoriesCss";

export default function DisplayAllCategories(props) {
  var classes = useStyles()
  var navigate=useNavigate()
  const [categories, setCategories] = useState([])
  const [open, setOpen] = useState(false);
  const [categoryid, setCategoryid] = useState('')
  const [companyid, setCompanyid] = useState('')
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('');
  const [btnStatus, setBtnStatus] = useState(false)
  const [oldPicture, setOldPicture] = useState('')
  const [message, setMessage] = useState("")



  const [categoryIcon, setCategoryIcon] = useState({ fileName: '/assets/watermark.png', bytes: '' });



  const handleImage = (event) => {
    setCategoryIcon({ fileName: URL.createObjectURL(event.target.files[0]), bytes: event.target.files[0] });

    setBtnStatus(true)
  };

  // const clearValue = () => {
  //   setCategory('')

  //   setDescription('')

  //   setCategoryIcon({ fileName: '/assets/watermark.png', bytes: '' })
  // }


  const handleOpenDialog = (rowData) => {
    setCategoryid(rowData.categoryid)
    setCompanyid(rowData.companyid)
    setCategory(rowData.category)

    setDescription(rowData.description)
    setStatus(rowData.status)

    setCategoryIcon({ fileName: `${ServerURL}/images/${rowData.icon}`, bytes: '' })
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const handleStatus = (temp) => {
    if (temp == 'Pending') { setStatus('Verified') }

    if (temp == "Verified") { setStatus('Pending') }
  }

  const handleEditData = async () => {
    var cd = new Date()
    var dd = cd.getFullYear() + "/" + (cd.getMonth() + 1) + "/" + cd.getDate() + " " + cd.getHours() + ":" + cd.getMinutes()

    var body = {
      'categoryid': categoryid,
      'companyid': companyid,
      'category': category,
      'description': description,

      'updatedat': dd,
      'createdby': 'ADMIN',
      'status': status
    }
    var result = await postData('category/edit_category_data', body)

    // alert(result.status)
    if (result.status) {
      setOpen(false)
      Swal.fire({
        icon: 'success',
        title: result.message,
      })
    }
    else {
      Swal.fire({
        icon: 'error',
        title: result.message,
      })

    }
    fetchAllCategories()
  }


  const handleCancel = () => {
    setCategoryIcon({ fileName: `${ServerURL}/images/${oldPicture}`, bytes: '' })
    setOldPicture('')
    setBtnStatus(false)
    setMessage('')
  }
  const handledelete=async(rowData)=>{

    // var result = await postData('company/delete_company_data', {companyid:rowData.companyid})
    // alert(result.status)

    setOpen(false)
      Swal.fire({
        title: 'Do you want to delete category?',
       
        showCancelButton: true,
        confirmButtonText: 'Delete',
      }).then(async(result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
      
    var res = await postData('category/delete_category_data', {categoryid:rowData.categoryid})
    if(result.status)
         { Swal.fire('Deleted!', '', 'success')
          fetchAllCategories()
        }
          else
          
            Swal.fire({
              icon: 'error',
              title: result.message,
             })
            

        } else if (result.isDenied) {
          Swal.fire('Changes are not saved', '', 'info')
        }
      })
  
     



  }

  const handleSaveLogo = async () => {

    var formData = new FormData()
    formData.append('categoryid', categoryid)
    formData.append('icon', categoryIcon.bytes)
    var result = await postData('category/edit_category_logo', formData)

    if (result.status) {
      setMessage("assets/tick.gif")
    }
    else {

      setMessage("")
    }
    fetchAllCategories()
    setBtnStatus(false)
  }

  const PictureButton = () => {
    return (<div>
      {btnStatus ? <div style={{ display: 'flex', padding: 10 }}>
        <Button onClick={handleCancel}>Cancel</Button>
        <Button onClick={handleSaveLogo}>Save</Button>
      </div> : <div style={{ fontSize: 10, color: 'green', fontWeight: 'bold' }}><img src={`${message}`}width="60"/></div>}

    </div>)
  }


  const ShowCategoryDetails = () => {
    return (
      <div>

        <Dialog
          open={open}
          // onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title" style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <img src="/assets/categories.png" width="30" />
              Edit Category
            </div>
            <div>
              <CloseIcon style={{ cursor: 'pointer' }} onClick={handleClose} />
            </div>
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2} style={{ marginTop: 10 }}>

              <Grid item xs={6}>
                <TextField value={companyid} fullWidth onChange={(event) => setCompanyid(event.target.value)} label="CompanyId" variant="outlined" />
              </Grid>

              <Grid item xs={6} >
                <TextField value={category} onChange={(event) => setCategory(event.target.value)} fullWidth label="Category" variant="outlined" />
              </Grid>

              <Grid item xs={6} >
                {status == "Pending" ? <Switch onChange={() => handleStatus(status)} /> : <Switch onChange={() => handleStatus(status)} defaultChecked />}
                {status}

              </Grid>

              <Grid item xs={3}>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop: 12 }}>

                  <IconButton color="primary" aria-label="upload picture" component="label">
                    <input hidden accept="image/*" type="file" onChange={handleImage} />
                    <PhotoCamera />
                  </IconButton>
                </div>
              </Grid>


              <Grid item xs={3}>
                <Avatar
                  alt="Remy Sharp"
                  variant="rounded"
                  src={categoryIcon.fileName}

                  sx={{ width: 56, height: 56 }}
                />
                <PictureButton />
              </Grid>

              <Grid item xs={6}>
                <TextField value={description} fullWidth onChange={(event) => setDescription(event.target.value)} label="Description" variant="outlined" />
              </Grid>



              {/* <Grid item xs={6}>
            <Button onClick={handleClick} fullWidth variant="contained">Submit</Button>

          </Grid>

          <Grid item xs={6}>

            <Button onClick={() => clearValue()} fullWidth variant="contained">Reset</Button>
          </Grid> */}

            </Grid>


          </DialogContent>
          <DialogActions>
            <Button onClick={handleEditData} >Edit</Button>
            <Button onClick={handleClose} >
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
  const fetchAllCategories = async () => {
    var result = await getData('category/fetch_all_category')
    setCategories(result.data)
  }
  useEffect(function () {
    fetchAllCategories()

  }, [])

  function showAllCategory() {
    return (
      <MaterialTable
        title={<span className={classes.headingstyle}>Category List</span>}
        columns={[
          {
            title: 'CompanyId', field: 'companyid',
            render: rowData => <div>{rowData.companyid}</div>
          },

          {
            title: 'Description', field: 'description',
          },


          {
            title: 'Category', field: 'category',
          },



          {
            title: 'Updation',
            render: rowData => <div>{rowData.createdat}<br />{rowData.updatedat}<br />{rowData.createdby}</div>
          },

          {
            title: 'Icon',
            render: rowData => <Avatar src={`${ServerURL}/images/${rowData.icon}`} style={{ width: 70, height: 70 }} variant="rounded" />
          },
          { title: 'Status', field: 'status' },
        ]}
        data={categories}
        actions={[

          
          { icon:'add',
            isFreeAction:true,
              tooltip:'Add Category',
              onClick: (event) =>navigate('/category')  },

          {
            icon: 'edit',
            tooltip: 'edit user',
            onClick: (event, rowData) => handleOpenDialog(rowData)
          },
          {
            icon: 'delete',
            tooltip: 'Delete User',
            onClick: (event, rowData) => handledelete(rowData)
          }
        ]}

      />
    )
  }

  return (<div className={classes.mainContainer}>
    <div className={classes.box}>
      {showAllCategory()}
      {ShowCategoryDetails()}
    </div>
  </div>)


}