import { useEffect, useState } from "react";
import MaterialTable from "@material-table/core";
import { getData, postData, ServerURL } from "../services/ServerServices";
import { useNavigate } from "react-router-dom";
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Avatar, Switch, TextField, Grid, IconButton, FormControl, InputLabel, OutlinedInput, InputAdornment, Select, MenuItem, Radio } from "@mui/material";
import PhotoCamera from '@mui/icons-material/PhotoCamera';
// import Visibility from '@mui/icons-material/Visibility';
// import VisibilityOff from '@mui/icons-material/VisibilityOff';
import CloseIcon from '@mui/icons-material/Close';
import Swal from 'sweetalert2';
import { useStyles } from "./DisplayAllProductListCss";
import { Description } from "@mui/icons-material";

export default function DisplayAllProducts(props) {
  var classes = useStyles()
  var navigate=useNavigate()
  const [productlist, setProductList] = useState([])
  const [open, setOpen] = useState(false);
  const [categoryid, setCategoryId] = useState('')
  const [productid, setProductId] = useState('')
  const [weight, setWeight] = useState('')
  const [price, setPrice] = useState('')
  const [offerprice, setOfferPrice] = useState('')
  const [description, setDescription] = useState('')

  const [images, setImages] = useState({ fileName: '/assets/watermark.png', bytes: '' });
  const [companyid, setCompanyId] = useState('')
  const [fillCategoryid, setFillCategoryid] = useState([])
  const [fillProductid, setFillProductid] = useState([])
  const [fillCompanyid, setFillCompanyid] = useState([])
  const [btnStatus, setBtnStatus] = useState(false)
  const [oldPicture, setOldPicture] = useState('')
  const [message, setMessage] = useState("")
   const [productlistid,setProductListId]=useState('')

  const handleImage = (event) => {
    setImages({ fileName: URL.createObjectURL(event.target.files[0]), bytes: event.target.files[0] });
   
    setBtnStatus(true)
  };

  const fatchAllCategories = async () => {
    var result = await getData('category/fetch_categoryid')
    setFillCategoryid(result.data)
  }

  const fatchAllProducts = async () => {
    var result = await getData('product/fetch_productid')
    setFillProductid(result.data)
  }

  const fatchAllCompany = async () => {
    var result = await getData('company/fetch_companyid')
    setFillCompanyid(result.data)
  }

  useEffect(function () {
    fatchAllCategories()
  }, [])

  useEffect(function () {
    fatchAllProducts()
    fatchAllCompany()
  }, [])

  const fill_Categoryid = () => {
    return fillCategoryid.map((item) => {
      return (<MenuItem value={item.categoryid}> {item.category}</MenuItem>)
    })
  }

  const fill_Productid = () => {
    return fillProductid.map((item) => {
      return (<MenuItem value={item.productid}> {item.productname}</MenuItem>)
    })
  }

  const fill_Companyid = () => {
    return fillCompanyid.map((item) => {
      return (<MenuItem value={item.companyid}> {item.companyname}</MenuItem>)
    })
  }

  const handleCategoryChange = (event) => {
    setCategoryId(event.target.value)
  }

  const handleProductChange = (event) => {
    setProductId(event.target.value)
  }

  const handleCompanyChange = (event) => {
    setCompanyId(event.target.value)
  }

  const handleOpenDialog = (rowData) => {
    fatchAllCategories(rowData.categoryid)
    fatchAllProducts(rowData.productid)
    fatchAllCompany(rowData.companyid)
    setCategoryId(rowData.categoryid)
    setProductId(rowData.productid)
    setWeight(rowData.weight)
    setPrice(rowData.price)
    setOfferPrice(rowData.offerprice)
    setDescription(rowData.description)
    setImages({ fileName: `${ServerURL}/images/${rowData.image}`, bytes: '' })
    setCompanyId(rowData.companyid)
    setOldPicture(rowData.image)
    setProductListId(rowData.productlistid)
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

//   const handleStatuss = (temp) => {
//     if (temp == 'Pending') { setStatuss('Verified') }

//     if (temp == "Verified") { setStatuss('Pending') }
//   }

  const handleEditData = async () => {
    var cd = new Date()
    var dd = cd.getFullYear() + "/" + (cd.getMonth() + 1) + "/" + cd.getDate() + " " + cd.getHours() + ":" + cd.getMinutes()

    var body = {
      'categoryid': categoryid,
      'productlistid': productlistid,
      'productid': productid,
      'weight': weight,
      'price': price,
      'offerprice': offerprice,
      'description': description,
      'updatedat': dd,
      'createdby': 'ADMIN',
      'companyid': companyid
    }
    var result = await postData('productlist/edit_productlist_data', body)

    if (result.status) {
      setOpen(false)
      Swal.fire({
        icon: 'success',
        title: result.message,
      })
    }
    else {
      Swal.fire({
        icon: 'error',
        title: result.message,
      })

    }
    fetchAllProducts()

  }

  const handleCancel = () => {
    setImages({ fileName: `${ServerURL}/images/${oldPicture}`, bytes: '' })
    setOldPicture('')
    setBtnStatus(false)
    setMessage('')
  }
  const handledelete=async(rowData)=>{

    // var result = await postData('company/delete_company_data', {companyid:rowData.companyid})
    // alert(result.status)

    setOpen(false)
      Swal.fire({
        title: 'Do you want to delete product?',
       
        showCancelButton: true,
        confirmButtonText: 'Delete',
      }).then(async(result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
        var res = await postData('productlist/delete_productlist_data', {productlistid:rowData.productlistid})
        if(res.status)
         { Swal.fire('Deleted!', '', 'success')
          fetchAllProducts()
        }
          else
          
            Swal.fire({
              icon: 'error',
              title: result.message,
             })
            

        } else if (result.isDenied) {
          Swal.fire('Changes are not saved', '', 'info')
        }
      })

  }

  const handleSaveLogo = async () => {

    var formData = new FormData()
    formData.append('productlistid',productlistid)
    formData.append('images', images.bytes)
    var result = await postData('productlist/edit_productlist_logo', formData)
    if (result.status) {
      setMessage("assets/tick.gif")
    }
    else {

      setMessage("")
    }
    fetchAllProducts()
    setBtnStatus(false)
  }

  const PictureButton = () => {
    return (<div>
      {btnStatus ? <div style={{ display: 'flex', padding: 10 }}>
        <Button onClick={handleCancel}>Cancel</Button>
        <Button onClick={handleSaveLogo}>Save</Button>
      </div> : <div style={{ fontSize: 10, color: 'green', fontWeight: 'bold' }}><img src={`${message}`}width="60"/></div>}

    </div>)
  }

  const ShowProductDetails = () => {
    return (
      <div>

        <Dialog
          open={open}
          // onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title" style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <img src="/assets/products.png" width="30" />
              Edit productlist
            </div>
            <div>
              <CloseIcon style={{ cursor: 'pointer' }} onClick={handleClose} />
            </div>
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2} style={{ marginTop: 10 }}>
              <Grid item xs={12}  >
                <div className={classes.headingStyle}>
                  ProductList Details
                </div>
              </Grid>
          
              <Grid item xs={6}>
                <TextField value={productlistid} fullWidth onChange={(event) => setProductListId(event.target.value)} label="ProductListId" variant="outlined" type={'number'} />
              </Grid>


              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Category Id</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={categoryid}
                    label="categoryid"
                    onChange={handleCategoryChange}
                  >
                    {/* <MenuItem value={'Choose Category...'}>Choose Category...</MenuItem> */}
                    {fill_Categoryid()}
                  </Select>
                </FormControl>
              </Grid>

              
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Product Id</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={productid}
                    label="productid"
                    onChange={handleProductChange}
                  >
                    {/* <MenuItem value={'Choose Category...'}>Choose Category...</MenuItem> */}
                    {fill_Productid()}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <TextField value={weight} fullWidth onChange={(event) => setWeight(event.target.value)} label="Weight" variant="outlined" />
              </Grid>


              <Grid item xs={12}>
                <TextField value={price} fullWidth onChange={(event) => setPrice(event.target.value)} label="Price" variant="outlined" />
              </Grid>
              
              <Grid item xs={12}>
                <TextField value={offerprice} fullWidth onChange={(event) => setOfferPrice(event.target.value)} label="offerprice" variant="outlined" />
              </Grid>

              <Grid item xs={12}>
                <TextField value={description} fullWidth onChange={(event) => setDescription(event.target.value)} label="Description" variant="outlined" />
              </Grid>


              
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Company Id</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={companyid}
                    label="companyid"
                    onChange={handleCompanyChange}
                  >
                    {/* <MenuItem value={'Choose Category...'}>Choose Category...</MenuItem> */}
                    {fill_Companyid()}
                  </Select>
                </FormControl>
              </Grid>
              

             


              <Grid item xs={3}>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop: 8 }}>

                  <IconButton color="primary" aria-label="upload picture" component="label">
                    <input hidden accept="image/*" type="file" onChange={handleImage} />
                    <PhotoCamera />
                  </IconButton>
                </div>
              </Grid>

              <Grid item xs={3}>
                <Avatar
                  alt="Remy Sharp"
                  variant="rounded"
                  src={images.fileName}

                  sx={{ width: 56, height: 56 }}
                />

                <PictureButton />

              </Grid>







            </Grid>


          </DialogContent>
          <DialogActions>
            <Button onClick={handleEditData}>Edit</Button>
            <Button onClick={handleClose} >
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
  const fetchAllProducts = async () => {

    var result = await getData('productlist/fetch_all_productlist')
    setProductList(result.data)
    console.log('Xxx', result.data)


  }


  useEffect(function () {
    fetchAllProducts()

  }, [])

  function showAllProduct() {
    return (
      <MaterialTable
        title={<span className={classes.headingStyle}>Product List</span>}
        columns={[
         

          {
            title: 'CategoryId', field: 'categoryid',
          },

          {
            title: 'ProductId', field: 'productid',
          },


          {
            title: 'Weight', field: 'weight',
          },

          {
            title: 'Price', field: 'price',
          },


          {
            title: 'OfferPrice', field: 'offerprice',
          },

          {
            title: 'Description', field: 'description',
          },
    
          {
            title: 'Images',
            render: rowData => <Avatar src={`${ServerURL}/images/${rowData.images}`} style={{ width: 70, height: 70 }} variant="rounded" />
          },

          {
            title: 'CompanyId', field: 'companyid',
          },


          {
            title: 'Updation',
            render: rowData => <div>{rowData.createdat}<br />{rowData.updatedat}<br />{rowData.createdby}</div>
          },
         

        ]}
        data={productlist}
        actions={[

          
          { icon:'add',
            isFreeAction:true,
              tooltip:'Add Product',
              onClick: (event) =>navigate('/productlist')  },

          {
            icon: 'edit',
            tooltip: 'edit user',
            onClick: (event, rowData) => handleOpenDialog(rowData)
          },
          {
            icon: 'delete',
            tooltip: 'Delete User',
            onClick: (event, rowData) => handledelete(rowData)
          }

        ]}
      />
    )
  }
  return (<div className={classes.mainContainer}>
    <div className={classes.box}>

      {showAllProduct()}
      {ShowProductDetails()}
    </div>
  </div>)

}