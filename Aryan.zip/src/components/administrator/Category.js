import React, { useState } from "react";
import { Avatar, TextField, Button, Grid, IconButton, FormControl, InputLable, OutlinedInput, InputAdornment, Select, MenuItem, } from "@mui/material";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useStyles } from "./CategoryCss";
import { postData } from "../services/ServerServices";
import { useNavigate } from 'react-router-dom';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import Swal from "sweetalert2";

export default function Category(props) {
  var navigate=useNavigate()
  var classes = useStyles();

  const [companyid, setCompanyid] = useState('')
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const[error,setError]=useState({})



  const [categoryIcon, setCategoryIcon] = useState({ fileName: '/assets/watermark.png', bytes: '' });



  const handleImage = (event) => {
    setCategoryIcon({ fileName: URL.createObjectURL(event.target.files[0]), bytes: event.target.files[0] });

  };

  const handleError=(inputs,value)=>{

    setError((prev)=>({...prev,[inputs]:value}))
 
 
  }

  const validation=()=>{

      var isValid=true
      if(!companyid)

      {
       handleError("companyid","Invalid CompanyId")
       isValid=false
      }

      if(!category)

      {
       handleError("category","Invalid category")
       isValid=false
      }

      if(!description)
      {
       handleError("description","Invalid Description")
       isValid=false
      }

      return isValid
    }
  


  const clearValue = () => {
    setCategory('')

    setDescription('')

    setCategoryIcon({ fileName: '/assets/watermark.png', bytes: '' })
  }


  const handleClick = async () => {
    if (validation()) {
    var cd = new Date()
    var dd = cd.getFullYear() + "/" + (cd.getMonth() + 1) + "/" + cd.getDate() + " " + cd.getHours() + ":" + cd.getMinutes()
    var formData = new FormData()
    formData.append('companyid',companyid)
    formData.append('category', category)
    formData.append('description', description)
    formData.append('icon', categoryIcon.bytes)
    
    formData.append('createdat', dd)
    formData.append('updatedat', dd)
    formData.append('createdby', 'ADMIN')
    formData.append('status','Pending')
    var result = await postData('category/add_new_category', formData)
    // alert(result.status)
    if (result.status) {
      Swal.fire({
        icon: 'success',
        title: result.message,
      })
    }

    else {
      Swal.fire({
        icon: 'error',
        title: result.message,
      })
    }
  
    }
    clearValue()


  }

  return (
    <div className={classes.mainContainer}>
      <div className={classes.box}>
        <Grid container spacing={2}>
          <Grid item xs={12}  >

          <div style={{display:'flex',flexDirection:'row'}}>
            <div className={classes.headingStyle}>
              Categories Details
            </div>
            </div>

<div>
<FormatListBulletedIcon onClick={()=>navigate('/displayallcategories')}/>
</div>

          </Grid>
          <Grid item xs={6}>
            <TextField error={!error.companyid?false:true} helperText={error.companyid} onFocus={()=>handleError("companyid",null)} value={companyid} fullWidth onChange={(event) => setCompanyid(event.target.value)} label="CompanyId" variant="outlined" />
          </Grid>

          <Grid item xs={6} >
            <TextField error={!error.category?false:true} helperText={error.category} onFocus={()=>handleError("category",null)} value={category} onChange={(event) => setCategory(event.target.value)} fullWidth label="Category" variant="outlined" />
          </Grid>
          <Grid item xs={3}>
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 12 }}>

              <IconButton color="primary" aria-label="upload picture" component="label">
                <input hidden accept="image/*" type="file" onChange={handleImage} />
                <PhotoCamera />
              </IconButton>
            </div>
          </Grid>


          <Grid item xs={3}>
            <Avatar
              alt="Remy Sharp"
              variant="rounded"
              src={categoryIcon.fileName}

              sx={{ width: 56, height: 56 }}
            />
          </Grid>

          <Grid item xs={6}>
            <TextField error={!error.description?false:true} helperText={error.description} onFocus={()=>handleError("description",null)} value={description} fullWidth onChange={(event) => setDescription(event.target.value)} label="Description" variant="outlined" />
          </Grid>



          <Grid item xs={6}>
            <Button onClick={handleClick} fullWidth variant="contained">Submit</Button>

          </Grid>

          <Grid item xs={6}>

            <Button onClick={() => clearValue()} fullWidth variant="contained">Reset</Button>
          </Grid>

        </Grid>
      </div>
    </div>
  )
}


