import React, { useEffect, useState } from "react";
import { Avatar, TextField, Button, Grid, IconButton, FormControl, OutlinedInput, InputAdornment, Select, MenuItem, InputLabel, FormLabel, FormControlLabel, } from "@mui/material";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import Radio from '@mui/material/Radio';
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useStyles } from "./ProductCss";
import { getData, postData } from "../services/ServerServices";
import { useNavigate } from 'react-router-dom';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import Swal from "sweetalert2";

export default function Product(props) {
  var classes = useStyles();
  var navigate = useNavigate();

  const [companyid, setCompanyId] = useState('')
  const [categoryid, setCategoryId] = useState('')
  const [productname, setProductName] = useState('')
  const [status, setStatus] = useState('')
  const [description, setDescription] = useState('')
  const [trending, setTrending] = useState('')
  const [deals, setDeals] = useState('')
  const [pricetype, setPriceType] = useState('')
  const [image, setImage] = useState({ fileName: '/assets/watermark.png', bytes: '' });

  const [fillCategoryid, setFillCategoryid] = useState([])
  // var result = await postData('product/add_new_product', formData)

  const [error, setError] = useState({})


  const handleClick = async () => {
    if (validation()) {
      var cd = new Date()
      var dd = cd.getFullYear() + "/" + (cd.getMonth() + 1) + "/" + cd.getDate() + " " + cd.getHours() + ":" + cd.getMinutes()
      var formData = new FormData()
      formData.append('companyid', companyid)
      formData.append('categoryid', categoryid)
      formData.append('productname', productname)
      formData.append('description', description)
      formData.append('status', status)
      formData.append('trending', trending)
      formData.append('deals', deals)
      formData.append('pricetype', pricetype)
      formData.append('image', image.bytes)
      formData.append('createdat', dd)
      formData.append('updatedat', dd)
      formData.append('createdby', 'ADMIN')
      formData.append('statuss', 'Pending')
      var result = await postData('product/add_new_product', formData)
      // alert(result.status)
      if (result.status) {
        Swal.fire({
          icon: 'success',
          title: result.message,
        })
      }
      else {
        Swal.fire({
          icon: 'error',
          title: result.message,
        })
      }
    }
  }
  const clearValue = () => {
    setCompanyId('')
    setCategoryId('Choose Category...')
    setProductName('')
    setDescription('')
    setStatus('')
    setTrending('')
    setDeals('')
    setPriceType('')
    setImage({ fileName: '/assets/watermark.png', bytes: '' })
  }






  const handleImage = (event) => {
    setImage({ fileName: URL.createObjectURL(event.target.files[0]), bytes: event.target.files[0] });
  };

  const fatchAllCategories = async () => {
    var result = await getData('category/fetch_categoryid')
    setFillCategoryid(result.data)
  }

  useEffect(function () {
    fatchAllCategories()
  }, [])


  const handleError = (inputs, value) => {
    setError((prev) => ({ ...prev, [inputs]: value }))
  }

  const validation = () => {

    var isValid = true
    if (!companyid) {
      handleError("companyid", "Invalid CompanyId Name")
      isValid = false
    }

    if (!categoryid) {
      handleError("categoryid", "Invalid categoryId Name")
      isValid = false
    }

    if (!status) {
      handleError("status", "Invalid Status")
      isValid = false
    }
    if (!productname) {
      handleError('productname', "Invalid Product Name")
    }

    if (!description) {
      handleError('description', "Pls Input Description")
      isValid = false
    }

    if (!trending) {
      handleError('trending', "Pls Select trending")
      isValid = false
    }

    if (!deals) {
      handleError('deals', "Pls Select Deals")
      isValid = false
    }

    if (!pricetype) {
      handleError('pricetype', "Pls Input Price")
      isValid = false
    }





    return isValid
  }


  const fill_Categoryid = () => {
    return fillCategoryid.map((item) => {
      return (<MenuItem value={item.categoryid}> {item.category}</MenuItem>)
    })
  }

  const handleCategoryChange = (event) => {
    setCategoryId(event.target.value)
  }

  return (<>
    <div className={classes.mainContainer}>
      <div className={classes.box}>
        <Grid container spacing={2}>
          <Grid item xs={12}  >

            <div style={{ display: 'flex', flexDirection: 'row' }}>
              <div className={classes.headingStyle}>
                Product Details
              </div>

            </div>

            <div>
              <FormatListBulletedIcon onClick={() => navigate('/displayallproducts')} />
            </div>

          </Grid>
          <Grid item xs={6}>
            <TextField error={!error.companyid ? false : true} helperText={error.companyid} onFocus={() => handleError("companyid", null)} value={companyid} fullWidth onChange={(event) => setCompanyId(event.target.value)} label="CompanyId" variant="outlined" type={'number'} />
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Category Id</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={categoryid}
                label="categoryid"
                onChange={handleCategoryChange}
                error={!error.categoryid ? false : true}
                onFocus={() => handleError('categorid', null)}
              >
                <MenuItem value={'Choose Category...'}>Choose Category...</MenuItem>
                {fill_Categoryid()}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Status</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={status}
                label="Status"
                onChange={(event) => setStatus(event.target.value)}
                error={!error.status ? false : true}
                onFocus={() => handleError('status', null)}
              >
                <MenuItem value={'Product Available'}>Product Available</MenuItem>
                <MenuItem value={'Product Not Available'}>Product Not Available</MenuItem>

              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={6} >
            <TextField error={!error.productname ? false : true} helperText={error.productname} onFocus={() => handleError("productname", null)} value={productname} onChange={(event) => setProductName(event.target.value)} fullWidth label="Product Name" variant="outlined" />
          </Grid>

          <Grid item xs={12}>
            <TextField error={!error.description ? false : true} helperText={error.description} onFocus={() => handleError("description", null)} value={description} fullWidth onChange={(event) => setDescription(event.target.value)} label="Description" variant="outlined" />
          </Grid>

          <Grid item xs={12}>
            <div>Trending</div>
            <Radio

              checked={trending === 'Yes'}
              onChange={(event) => setTrending(event.target.value)}
              value="Yes"
              // name="radio-buttons"
              inputProps={{ 'aria-label': 'A' }}
            />Yes
            <Radio
              checked={trending === 'No'}
              onChange={(event) => setTrending(event.target.value)}
              error={!error.trending ? false : true}
              onFocus={() => handleError('trending', null)}
              value="No"
              name="radio-buttons"
              inputProps={{ 'aria-label': 'A' }}
            />No
            <div style={{padding:5,fontSize:12,color:"red"}}>{error.trending}</div>
          </Grid>

          <Grid item xs={6}>
            <div>Deals</div>
            <Radio

              checked={deals === 'Yes'}
              onChange={(event) => setDeals(event.target.value)}
              value="Yes"
              error={!error.deals ? false : true}
              onFocus={() => handleError('deals', null)}
              // name="radio-buttons"
              inputProps={{ 'aria-label': 'A' }}
            />Yes
            <Radio
              checked={deals === 'No'}
              onChange={(event) => setDeals(event.target.value)}
              value="No"
              name="radio-buttons"
              inputProps={{ 'aria-label': 'A' }}
            />No
                        <div style={{padding:5,fontSize:12,color:"red"}}>{error.deals}</div>
          </Grid>

          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">Price Type</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={pricetype}
                label="Price Type"
                onChange={(event) => setPriceType(event.target.value)}
                error={!error.pricetype ? false : true}
                onFocus={() => handleError('pricetype', null)}
              >
                <MenuItem value={'Kilogram'}>Kilogram</MenuItem>
                <MenuItem value={'Litre'}>Litre</MenuItem>
                <MenuItem value={'Pieces'}>Pieces</MenuItem>
              </Select>
            </FormControl>
          </Grid>


          <Grid item xs={3}>
            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 12 }}>

              <IconButton color="primary" aria-label="upload picture" component="label">
                <input hidden accept="image/*" type="file" onChange={handleImage} />
                <PhotoCamera />
              </IconButton>
            </div>
          </Grid>

          <Grid item xs={3}>
            <Avatar
              alt="Remy Sharp"
              variant="rounded"
              src={image.fileName}
              sx={{ width: 56, height: 56 }}
            />
          </Grid>
          <Grid item xs={3}>
            <Button fullWidth variant="contained" onClick={handleClick}>Submit</Button>
          </Grid>
          <Grid item xs={3}>
            <Button fullWidth variant="contained" onClick={handleClick}>Reset</Button>
          </Grid>
        </Grid>
      </div>
    </div>
  </>

  )
}
