import { useEffect, useState } from "react";
import MaterialTable from "@material-table/core";
import { getData, postData, ServerURL } from "../services/ServerServices";
import { useNavigate } from "react-router-dom";
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Avatar, Switch, TextField, Grid, IconButton, FormControl, InputLabel, OutlinedInput, InputAdornment, Select, MenuItem, Radio } from "@mui/material";
import PhotoCamera from '@mui/icons-material/PhotoCamera';
// import Visibility from '@mui/icons-material/Visibility';
// import VisibilityOff from '@mui/icons-material/VisibilityOff';
import CloseIcon from '@mui/icons-material/Close';
import Swal from 'sweetalert2';
import { useStyles } from "./DisplayAllProductsCss";
import { Description } from "@mui/icons-material";

export default function DisplayAllProducts(props) {
  var classes = useStyles()
  var navigate=useNavigate()
  const [products, setProducts] = useState([])
  const [open, setOpen] = useState(false);
  const [productid, setProductId] = useState('')
  const [companyid, setCompanyId] = useState('')
  const [categoryid, setCategoryId] = useState('')
  const [productname, setProductName] = useState('')
  const [status, setStatus] = useState('')

  const [description, setDescription] = useState('')
  const [trending, setTrending] = useState('')
  const [deals, setDeals] = useState('')
  const [pricetype, setPriceType] = useState('')
  const [image, setImage] = useState({ fileName: '/assets/watermark.png', bytes: '' });
  const [statuss, setStatuss] = useState('')
  const [fillCategoryid, setFillCategoryid] = useState([])
  const [btnStatus, setBtnStatus] = useState(false)
  const [oldPicture, setOldPicture] = useState('')
  const [message, setMessage] = useState("")



  // const clearValue = () => {
  //     setCompanyId('')
  //     setCategoryId('Choose Category...')
  //     setProductName('')
  //     setDescription('')
  //     setStatus('')
  //     setTrending('')
  //     setDeals('')
  //     setPriceType('')
  //     setImage({ fileName: '/assets/watermark.png', bytes: '' })
  //   }






  const handleImage = (event) => {
    setImage({ fileName: URL.createObjectURL(event.target.files[0]), bytes: event.target.files[0] });

    setBtnStatus(true)
  };

  const fatchAllCategories = async () => {
    var result = await getData('category/fetch_categoryid')
    setFillCategoryid(result.data)
  }

  useEffect(function () {
    fatchAllCategories()
  }, [])

  const fill_Categoryid = () => {
    return fillCategoryid.map((item) => {
      return (<MenuItem value={item.categoryid}> {item.category}</MenuItem>)
    })
  }

  const handleCategoryChange = (event) => {
    setCategoryId(event.target.value)
  }

  const handleOpenDialog = (rowData) => {
    fatchAllCategories(rowData.categoryid)
    setProductId(rowData.productid)
    setCompanyId(rowData.companyid)
    setCategoryId(rowData.categoryid)
    setProductName(rowData.productname)
    setDescription(rowData.description)
    setStatus(rowData.status)
    setTrending(rowData.trending)
    setDeals(rowData.deals)
    setPriceType(rowData.pricetype)
    setImage({ fileName: `${ServerURL}/images/${rowData.image}`, bytes: '' })
    setStatuss(rowData.statuss)
    setOldPicture(rowData.image)
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const handleStatuss = (temp) => {
    if (temp == 'Pending') { setStatuss('Verified') }

    if (temp == "Verified") { setStatuss('Pending') }
  }

  const handleEditData = async () => {
    var cd = new Date()
    var dd = cd.getFullYear() + "/" + (cd.getMonth() + 1) + "/" + cd.getDate() + " " + cd.getHours() + ":" + cd.getMinutes()

    var body = {
      'productid': productid,
      'companyid': companyid,
      'categoryid': categoryid,
      'productname': productname,
      'status': status,
      'description': description,
      'trending': trending,
      'deals': deals,
      'pricetype': pricetype,
      'updatedat': dd,
      'createdby': 'ADMIN',
      'statuss': statuss
    }
    var result = await postData('product/edit_product_data', body)

    if (result.status) {
      setOpen(false)
      Swal.fire({
        icon: 'success',
        title: result.message,
      })
    }
    else {
      Swal.fire({
        icon: 'error',
        title: result.message,
      })

    }
    fetchAllProducts()

  }

  const handleCancel = () => {
    setImage({ fileName: `${ServerURL}/images/${oldPicture}`, bytes: '' })
    setOldPicture('')
    setBtnStatus(false)
    setMessage('')
  }
  const handledelete=async(rowData)=>{

    // var result = await postData('company/delete_company_data', {companyid:rowData.companyid})
    // alert(result.status)

    setOpen(false)
      Swal.fire({
        title: 'Do you want to delete product?',
       
        showCancelButton: true,
        confirmButtonText: 'Delete',
      }).then(async(result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
        var res = await postData('product/delete_product_data', {productid:rowData.productid})
        if(res.status)
         { Swal.fire('Deleted!', '', 'success')
          fetchAllProducts()
        }
          else
          
            Swal.fire({
              icon: 'error',
              title: result.message,
             })
            

        } else if (result.isDenied) {
          Swal.fire('Changes are not saved', '', 'info')
        }
      })
  
     




  }

  const handleSaveLogo = async () => {

    var formData = new FormData()
    formData.append('productid', productid)
    formData.append('image', image.bytes)
    var result = await postData('product/edit_product_logo', formData)

    if (result.status) {
      setMessage("assets/tick.gif")
    }
    else {

      setMessage("")
    }
    fetchAllProducts()
    setBtnStatus(false)
  }

  const PictureButton = () => {
    return (<div>
      {btnStatus ? <div style={{ display: 'flex', padding: 10 }}>
        <Button onClick={handleCancel}>Cancel</Button>
        <Button onClick={handleSaveLogo}>Save</Button>
      </div> : <div style={{ fontSize: 10, color: 'green', fontWeight: 'bold' }}><img src={`${message}`}width="60"/></div>}

    </div>)
  }

  const ShowProductDetails = () => {
    return (
      <div>

        <Dialog
          open={open}
          // onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title" style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <img src="/assets/products.png" width="30" />
              Edit products
            </div>
            <div>
              <CloseIcon style={{ cursor: 'pointer' }} onClick={handleClose} />
            </div>
          </DialogTitle>
          <DialogContent>
            <Grid container spacing={2} style={{ marginTop: 10 }}>
              <Grid item xs={12}  >
                <div className={classes.headingStyle}>
                  Product Details
                </div>
              </Grid>
              <Grid item xs={6}>
                <TextField value={companyid} fullWidth onChange={(event) => setCompanyId(event.target.value)} label="CompanyId" variant="outlined" type={'number'} />
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Category Id</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={categoryid}
                    label="categoryid"
                    onChange={handleCategoryChange}
                  >
                    {/* <MenuItem value={'Choose Category...'}>Choose Category...</MenuItem> */}
                    {fill_Categoryid()}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Status</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={status}
                    label="Status"
                    onChange={(event) => setStatus(event.target.value)}
                  >
                    <MenuItem value={'Product Available'}>Product Available</MenuItem>
                    <MenuItem value={'Product Not Available'}>Product Not Available</MenuItem>

                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6} >
                <TextField value={productname} onChange={(event) => setProductName(event.target.value)} fullWidth label="Product Name" variant="outlined" />
              </Grid>

              <Grid item xs={12}>
                <TextField value={description} fullWidth onChange={(event) => setDescription(event.target.value)} label="Description" variant="outlined" />
              </Grid>

              <Grid item xs={12}>
                <div>Trending</div>
                <Radio

                  checked={trending === 'Yes'}
                  onChange={(event) => setTrending(event.target.value)}
                  value="Yes"
                  // name="radio-buttons"
                  inputProps={{ 'aria-label': 'A' }}
                />Yes
                <Radio
                  checked={trending === 'No'}
                  onChange={(event) => setTrending(event.target.value)}
                  value="No"
                  name="radio-buttons"
                  inputProps={{ 'aria-label': 'A' }}
                />No
              </Grid>

              <Grid item xs={6}>
                <div>Deals</div>
                <Radio

                  checked={deals === 'Yes'}
                  onChange={(event) => setDeals(event.target.value)}
                  value="Yes"
                  // name="radio-buttons"
                  inputProps={{ 'aria-label': 'A' }}
                />Yes
                <Radio
                  checked={deals === 'No'}
                  onChange={(event) => setDeals(event.target.value)}
                  value="No"
                  name="radio-buttons"
                  inputProps={{ 'aria-label': 'A' }}
                />No
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Price Type</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    //   value={}
                    label="Price Type"
                    onChange={(event) => setPriceType(event.target.value)}
                  >
                    <MenuItem value={'Kilogram'}>Kilogram</MenuItem>
                    <MenuItem value={'Litre'}>Litre</MenuItem>
                    <MenuItem value={'Pieces'}>Pieces</MenuItem>

                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6} >
                {statuss == "Pending" ? <Switch onChange={() => handleStatuss(statuss)} /> : <Switch onChange={() => handleStatuss(statuss)} defaultChecked />}
                {statuss}

              </Grid>


              <Grid item xs={3}>
                <div style={{ display: 'flex', justifyContent: 'center', marginTop: 8 }}>

                  <IconButton color="primary" aria-label="upload picture" component="label">
                    <input hidden accept="image/*" type="file" onChange={handleImage} />
                    <PhotoCamera />
                  </IconButton>
                </div>
              </Grid>

              <Grid item xs={3}>
                <Avatar
                  alt="Remy Sharp"
                  variant="rounded"
                  src={image.fileName}

                  sx={{ width: 56, height: 56 }}
                />

                <PictureButton />

              </Grid>







            </Grid>


          </DialogContent>
          <DialogActions>
            <Button onClick={handleEditData}>Edit</Button>
            <Button onClick={handleClose} >
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
  const fetchAllProducts = async () => {

    var result = await getData('product/fetch_all_products')
    setProducts(result.data)
    console.log('Xxx', result.data)


  }


  useEffect(function () {
    fetchAllProducts()

  }, [])

  function showAllProduct() {
    return (
      <MaterialTable
        title={<span className={classes.headingStyle}>Product List</span>}
        columns={[
          {
            title: 'CompanyId', field: 'companyid',
          },

          {
            title: 'CategoryId', field: 'categoryid',
          },

          {
            title: 'Product Name', field: 'productname',
          },

          {
            title: 'Description', field: 'description',
          },


          {
            title: 'Status', field: 'status',
          },

          {
            title: 'Trending', field: 'trending',
          },

          {
            title: 'Deals', field: 'deals',
          },

          {
            title: 'Price Type', field: 'pricetype',
          },

          { title: 'Statuss', field: 'statuss' },


          {
            title: 'Updation',
            render: rowData => <div>{rowData.createdat}<br />{rowData.updatedat}<br />{rowData.createdby}</div>
          },
          {
            title: 'Image',
            render: rowData => <Avatar src={`${ServerURL}/images/${rowData.image}`} style={{ width: 70, height: 70 }} variant="rounded" />
          },

        ]}
        data={products}
        actions={[

          
          { icon:'add',
            isFreeAction:true,
              tooltip:'Add Product',
              onClick: (event) =>navigate('/product')  },

          {
            icon: 'edit',
            tooltip: 'edit user',
            onClick: (event, rowData) => handleOpenDialog(rowData)
          },
          {
            icon: 'delete',
            tooltip: 'Delete User',
            onClick: (event, rowData) => handledelete(rowData)
          }

        ]}
      />
    )
  }
  return (<div className={classes.mainContainer}>
    <div className={classes.box}>

      {showAllProduct()}
      {ShowProductDetails()}
    </div>
  </div>)

}